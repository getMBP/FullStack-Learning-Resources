package com.code.DSALGO;

public class ToLower {
	
	public static String toLowerCase(String str) {
	        
	        char[] arr = str.toCharArray();
	        System.out.println(arr); 
	         for(int i =0 ; i <arr.length;i++) {
	        	  arr[i] = Character.toLowerCase(arr[i]); //Character.toLowerCase(ch1);
	        	  System.out.println(arr[i]);
	         }
	        
			return  String.valueOf(arr);
	     
	    }
	
	
	public static void main(String[] args) {
		
		
		System.out.println(ToLower.toLowerCase("ABc"));
		
	}

}
