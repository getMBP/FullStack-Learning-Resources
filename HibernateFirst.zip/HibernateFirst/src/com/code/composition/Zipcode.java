package com.code.composition;

import javax.persistence.Embeddable;

@Embeddable 
public class Zipcode {
	public String zip;

	public Zipcode() {
	}
}